--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: emissions_co2_2004; Type: TABLE; Schema: public; Owner: nico; Tablespace: 
--

CREATE TABLE emissions_co2_2004 (
    name character varying(200),
    metric_tons double precision,
    id integer NOT NULL
);


ALTER TABLE public.emissions_co2_2004 OWNER TO nico;

--
-- Name: emissions_co2_2004_id_seq; Type: SEQUENCE; Schema: public; Owner: nico
--

CREATE SEQUENCE emissions_co2_2004_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.emissions_co2_2004_id_seq OWNER TO nico;

--
-- Name: emissions_co2_2004_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nico
--

ALTER SEQUENCE emissions_co2_2004_id_seq OWNED BY emissions_co2_2004.id;


--
-- Name: emissions_co2_2004_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nico
--

SELECT pg_catalog.setval('emissions_co2_2004_id_seq', 206, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nico
--

ALTER TABLE emissions_co2_2004 ALTER COLUMN id SET DEFAULT nextval('emissions_co2_2004_id_seq'::regclass);


--
-- Data for Name: emissions_co2_2004; Type: TABLE DATA; Schema: public; Owner: nico
--

INSERT INTO emissions_co2_2004 VALUES ('Afghanistan', 692.92692, 1);
INSERT INTO emissions_co2_2004 VALUES ('Albania', 3673.61256, 2);
INSERT INTO emissions_co2_2004 VALUES ('Algeria', 194001.20619999999, 3);
INSERT INTO emissions_co2_2004 VALUES ('Angola', 7897.1671200000001, 4);
INSERT INTO emissions_co2_2004 VALUES ('Antigua and Barbuda', 414.28964000000002, 5);
INSERT INTO emissions_co2_2004 VALUES ('Argentina', 141786.04644000001, 6);
INSERT INTO emissions_co2_2004 VALUES ('Armenia', 3647.9486000000002, 7);
INSERT INTO emissions_co2_2004 VALUES ('Aruba', 2155.7726400000001, 8);
INSERT INTO emissions_co2_2004 VALUES ('Australia', 326757.20500000002, 9);
INSERT INTO emissions_co2_2004 VALUES ('Austria', 69846.300279999996, 10);
INSERT INTO emissions_co2_2004 VALUES ('Azerbaijan', 31365.025399999999, 11);
INSERT INTO emissions_co2_2004 VALUES ('Bahamas', 2009.1214399999999, 12);
INSERT INTO emissions_co2_2004 VALUES ('Bahrain', 16949.212439999999, 13);
INSERT INTO emissions_co2_2004 VALUES ('Bangladesh', 37165.08036, 14);
INSERT INTO emissions_co2_2004 VALUES ('Barbados', 1268.53288, 15);
INSERT INTO emissions_co2_2004 VALUES ('Belarus', 64889.489719999998, 16);
INSERT INTO emissions_co2_2004 VALUES ('Belgium', 100716.37788, 17);
INSERT INTO emissions_co2_2004 VALUES ('Belize', 791.91647999999998, 18);
INSERT INTO emissions_co2_2004 VALUES ('Benin', 2386.7482799999998, 19);
INSERT INTO emissions_co2_2004 VALUES ('Bermuda', 549.94200000000001, 20);
INSERT INTO emissions_co2_2004 VALUES ('Bhutan', 414.28964000000002, 21);
INSERT INTO emissions_co2_2004 VALUES ('Bolivia', 6973.2645599999996, 22);
INSERT INTO emissions_co2_2004 VALUES ('Bosnia and Herzegovina', 15596.35512, 23);
INSERT INTO emissions_co2_2004 VALUES ('Botswana', 4300.5464400000001, 24);
INSERT INTO emissions_co2_2004 VALUES ('Brazil', 331794.67372000002, 25);
INSERT INTO emissions_co2_2004 VALUES ('British Virgin Islands', 84.324439999999996, 26);
INSERT INTO emissions_co2_2004 VALUES ('Brunei Darussalam', 8810.0708400000003, 27);
INSERT INTO emissions_co2_2004 VALUES ('Bulgaria', 42558.178240000001, 28);
INSERT INTO emissions_co2_2004 VALUES ('Burkina Faso', 1096.2177200000001, 29);
INSERT INTO emissions_co2_2004 VALUES ('Burundi', 219.9768, 30);
INSERT INTO emissions_co2_2004 VALUES ('Cambodia', 535.27688000000001, 31);
INSERT INTO emissions_co2_2004 VALUES ('Cameroon', 3838.5951599999999, 32);
INSERT INTO emissions_co2_2004 VALUES ('Canada', 639402.89827999996, 33);
INSERT INTO emissions_co2_2004 VALUES ('Cape Verde', 274.971, 34);
INSERT INTO emissions_co2_2004 VALUES ('Cayman Islands', 311.63380000000001, 35);
INSERT INTO emissions_co2_2004 VALUES ('Central African Republic', 252.97332, 36);
INSERT INTO emissions_co2_2004 VALUES ('Chad', 124.65352, 37);
INSERT INTO emissions_co2_2004 VALUES ('Chile', 62418.417000000001, 38);
INSERT INTO emissions_co2_2004 VALUES ('China, Hong Kong Special Administrative Region', 37410.721120000002, 40);
INSERT INTO emissions_co2_2004 VALUES ('China, Macao Special Administrative Region', 2207.1005599999999, 41);
INSERT INTO emissions_co2_2004 VALUES ('Colombia', 53634.010119999999, 42);
INSERT INTO emissions_co2_2004 VALUES ('Comoros', 87.990719999999996, 43);
INSERT INTO emissions_co2_2004 VALUES ('Congo', 3541.6264799999999, 44);
INSERT INTO emissions_co2_2004 VALUES ('Cook Islands', 29.33024, 45);
INSERT INTO emissions_co2_2004 VALUES ('Costa Rica', 6404.9911599999996, 46);
INSERT INTO emissions_co2_2004 VALUES ('Cote d''Ivoire', 5162.1222399999997, 47);
INSERT INTO emissions_co2_2004 VALUES ('Croatia', 23500.854800000001, 48);
INSERT INTO emissions_co2_2004 VALUES ('Cuba', 25817.943759999998, 49);
INSERT INTO emissions_co2_2004 VALUES ('Cyprus', 6749.6214799999998, 50);
INSERT INTO emissions_co2_2004 VALUES ('Czech Republic', 116990.9948, 51);
INSERT INTO emissions_co2_2004 VALUES ('Democratic Republic of the Congo', 2104.44472, 52);
INSERT INTO emissions_co2_2004 VALUES ('Denmark', 52955.748319999999, 53);
INSERT INTO emissions_co2_2004 VALUES ('Djibouti', 366.62799999999999, 54);
INSERT INTO emissions_co2_2004 VALUES ('Dominica', 106.32212, 55);
INSERT INTO emissions_co2_2004 VALUES ('Dominican Republic', 19640.26196, 56);
INSERT INTO emissions_co2_2004 VALUES ('Ecuador', 29267.913240000002, 57);
INSERT INTO emissions_co2_2004 VALUES ('Egypt', 158236.64480000001, 58);
INSERT INTO emissions_co2_2004 VALUES ('El Salvador', 6166.6829600000001, 59);
INSERT INTO emissions_co2_2004 VALUES ('Equatorial Guinea', 5426.0944, 60);
INSERT INTO emissions_co2_2004 VALUES ('Eritrea', 755.25368000000003, 61);
INSERT INTO emissions_co2_2004 VALUES ('Estonia', 18943.66876, 62);
INSERT INTO emissions_co2_2004 VALUES ('Ethiopia', 7981.4915600000004, 63);
INSERT INTO emissions_co2_2004 VALUES ('Faeroe Islands', 659.93039999999996, 64);
INSERT INTO emissions_co2_2004 VALUES ('Fiji', 1070.55376, 66);
INSERT INTO emissions_co2_2004 VALUES ('Finland', 65798.727159999995, 67);
INSERT INTO emissions_co2_2004 VALUES ('France', 373692.92155999999, 68);
INSERT INTO emissions_co2_2004 VALUES ('French Guiana', 1004.5607199999999, 69);
INSERT INTO emissions_co2_2004 VALUES ('French Polynesia', 670.92924000000005, 70);
INSERT INTO emissions_co2_2004 VALUES ('Gabon', 1371.1887200000001, 71);
INSERT INTO emissions_co2_2004 VALUES ('Gambia', 285.96983999999998, 72);
INSERT INTO emissions_co2_2004 VALUES ('Georgia', 3911.92076, 73);
INSERT INTO emissions_co2_2004 VALUES ('Germany', 808766.70288, 74);
INSERT INTO emissions_co2_2004 VALUES ('Ghana', 7189.5750799999996, 75);
INSERT INTO emissions_co2_2004 VALUES ('Gibraltar', 373.96055999999999, 76);
INSERT INTO emissions_co2_2004 VALUES ('Greece', 96694.468720000004, 77);
INSERT INTO emissions_co2_2004 VALUES ('Greenland', 571.93967999999995, 78);
INSERT INTO emissions_co2_2004 VALUES ('Grenada', 216.31052, 79);
INSERT INTO emissions_co2_2004 VALUES ('Guadeloupe', 1734.1504399999999, 80);
INSERT INTO emissions_co2_2004 VALUES ('Guatemala', 12219.711240000001, 81);
INSERT INTO emissions_co2_2004 VALUES ('Guinea', 1338.1922, 82);
INSERT INTO emissions_co2_2004 VALUES ('Guinea-Bissau', 271.30471999999997, 83);
INSERT INTO emissions_co2_2004 VALUES ('Guyana', 1444.51432, 84);
INSERT INTO emissions_co2_2004 VALUES ('Haiti', 1756.1481200000001, 85);
INSERT INTO emissions_co2_2004 VALUES ('Honduras', 7614.8635599999998, 86);
INSERT INTO emissions_co2_2004 VALUES ('Hungary', 57182.969160000001, 87);
INSERT INTO emissions_co2_2004 VALUES ('Iceland', 2229.0982399999998, 88);
INSERT INTO emissions_co2_2004 VALUES ('India', 1342962.0302800001, 89);
INSERT INTO emissions_co2_2004 VALUES ('Indonesia', 378250.10759999999, 90);
INSERT INTO emissions_co2_2004 VALUES ('Iraq', 81651.721879999997, 92);
INSERT INTO emissions_co2_2004 VALUES ('Ireland', 42352.866560000002, 93);
INSERT INTO emissions_co2_2004 VALUES ('Israel', 71246.819239999997, 94);
INSERT INTO emissions_co2_2004 VALUES ('Italy', 449947.87927999999, 95);
INSERT INTO emissions_co2_2004 VALUES ('Jamaica', 10591.88292, 96);
INSERT INTO emissions_co2_2004 VALUES ('Japan', 1257962.9947599999, 97);
INSERT INTO emissions_co2_2004 VALUES ('Jordan', 16465.263480000001, 98);
INSERT INTO emissions_co2_2004 VALUES ('Kazakhstan', 200277.87755999999, 99);
INSERT INTO emissions_co2_2004 VALUES ('Kenya', 10588.216640000001, 100);
INSERT INTO emissions_co2_2004 VALUES ('Kiribati', 29.33024, 101);
INSERT INTO emissions_co2_2004 VALUES ('Kuwait', 99363.520560000004, 104);
INSERT INTO emissions_co2_2004 VALUES ('Kyrgyzstan', 5726.7293600000003, 105);
INSERT INTO emissions_co2_2004 VALUES ('Lao People''s Democratic Republic', 1279.53172, 106);
INSERT INTO emissions_co2_2004 VALUES ('Latvia', 7097.9180800000004, 107);
INSERT INTO emissions_co2_2004 VALUES ('Lebanon', 16263.61808, 108);
INSERT INTO emissions_co2_2004 VALUES ('Liberia', 469.28384, 109);
INSERT INTO emissions_co2_2004 VALUES ('Lithuania', 13308.5964, 111);
INSERT INTO emissions_co2_2004 VALUES ('Luxembourg', 11277.477279999999, 112);
INSERT INTO emissions_co2_2004 VALUES ('Madagascar', 2731.3786, 113);
INSERT INTO emissions_co2_2004 VALUES ('Malawi', 1044.8897999999999, 114);
INSERT INTO emissions_co2_2004 VALUES ('Malaysia', 177583.60436, 115);
INSERT INTO emissions_co2_2004 VALUES ('Maldives', 725.92344000000003, 116);
INSERT INTO emissions_co2_2004 VALUES ('Mali', 564.60712000000001, 117);
INSERT INTO emissions_co2_2004 VALUES ('Malta', 2452.7413200000001, 118);
INSERT INTO emissions_co2_2004 VALUES ('Martinique', 1290.5305599999999, 119);
INSERT INTO emissions_co2_2004 VALUES ('Mauritania', 2555.39716, 120);
INSERT INTO emissions_co2_2004 VALUES ('Mauritius', 3196.9961600000001, 121);
INSERT INTO emissions_co2_2004 VALUES ('Mexico', 438021.47044, 122);
INSERT INTO emissions_co2_2004 VALUES ('Mongolia', 8553.4312399999999, 123);
INSERT INTO emissions_co2_2004 VALUES ('Montserrat', 62.32676, 124);
INSERT INTO emissions_co2_2004 VALUES ('Morocco', 41168.65812, 125);
INSERT INTO emissions_co2_2004 VALUES ('Mozambique', 2166.7714799999999, 126);
INSERT INTO emissions_co2_2004 VALUES ('Namibia', 2471.0727200000001, 128);
INSERT INTO emissions_co2_2004 VALUES ('Nauru', 142.98491999999999, 129);
INSERT INTO emissions_co2_2004 VALUES ('Nepal', 3043.0124000000001, 130);
INSERT INTO emissions_co2_2004 VALUES ('Netherlands', 142061.01744, 131);
INSERT INTO emissions_co2_2004 VALUES ('Netherlands Antilles', 4087.9022, 132);
INSERT INTO emissions_co2_2004 VALUES ('New Caledonia', 2577.3948399999999, 133);
INSERT INTO emissions_co2_2004 VALUES ('New Zealand', 31570.337080000001, 134);
INSERT INTO emissions_co2_2004 VALUES ('Nicaragua', 4007.24404, 135);
INSERT INTO emissions_co2_2004 VALUES ('Niger', 1213.5386800000001, 136);
INSERT INTO emissions_co2_2004 VALUES ('Nigeria', 114024.97427999999, 137);
INSERT INTO emissions_co2_2004 VALUES ('Niue', 3.66628, 138);
INSERT INTO emissions_co2_2004 VALUES ('Norway', 87602.094320000004, 139);
INSERT INTO emissions_co2_2004 VALUES ('Occupied Palestinian Territory', 648.93155999999999, 140);
INSERT INTO emissions_co2_2004 VALUES ('Oman', 30899.40784, 141);
INSERT INTO emissions_co2_2004 VALUES ('Pakistan', 125669.07956, 142);
INSERT INTO emissions_co2_2004 VALUES ('Palau', 238.3082, 143);
INSERT INTO emissions_co2_2004 VALUES ('Panama', 5660.73632, 144);
INSERT INTO emissions_co2_2004 VALUES ('Papua New Guinea', 2449.0750400000002, 145);
INSERT INTO emissions_co2_2004 VALUES ('Paraguay', 4179.5591999999997, 146);
INSERT INTO emissions_co2_2004 VALUES ('Peru', 31493.3452, 147);
INSERT INTO emissions_co2_2004 VALUES ('Philippines', 80511.508799999996, 148);
INSERT INTO emissions_co2_2004 VALUES ('Poland', 307237.93027999997, 149);
INSERT INTO emissions_co2_2004 VALUES ('Portugal', 58906.120759999998, 150);
INSERT INTO emissions_co2_2004 VALUES ('Qatar', 52904.420400000003, 151);
INSERT INTO emissions_co2_2004 VALUES ('Republic of Moldova', 7684.5228800000004, 152);
INSERT INTO emissions_co2_2004 VALUES ('Reunion', 2276.7598800000001, 153);
INSERT INTO emissions_co2_2004 VALUES ('Romania', 90425.129920000007, 154);
INSERT INTO emissions_co2_2004 VALUES ('Rwanda', 571.93967999999995, 156);
INSERT INTO emissions_co2_2004 VALUES ('Saint Helena', 10.99884, 157);
INSERT INTO emissions_co2_2004 VALUES ('Saint Kitts and Nevis', 124.65352, 158);
INSERT INTO emissions_co2_2004 VALUES ('Saint Lucia', 366.62799999999999, 159);
INSERT INTO emissions_co2_2004 VALUES ('Saint Pierre and Miquelon', 62.32676, 160);
INSERT INTO emissions_co2_2004 VALUES ('Saint Vincent and the Grenadines', 197.97911999999999, 161);
INSERT INTO emissions_co2_2004 VALUES ('Samoa', 150.31747999999999, 162);
INSERT INTO emissions_co2_2004 VALUES ('Sao Tome and Principe', 91.656999999999996, 163);
INSERT INTO emissions_co2_2004 VALUES ('Saudi Arabia', 308392.80848000001, 164);
INSERT INTO emissions_co2_2004 VALUES ('Senegal', 4993.47336, 165);
INSERT INTO emissions_co2_2004 VALUES ('Serbia and Montenegro', 53322.376320000003, 166);
INSERT INTO emissions_co2_2004 VALUES ('Seychelles', 546.27571999999998, 167);
INSERT INTO emissions_co2_2004 VALUES ('Sierra Leone', 993.56187999999997, 168);
INSERT INTO emissions_co2_2004 VALUES ('Singapore', 52251.822560000001, 169);
INSERT INTO emissions_co2_2004 VALUES ('Slovakia', 36288.839440000003, 170);
INSERT INTO emissions_co2_2004 VALUES ('Slovenia', 16212.29016, 171);
INSERT INTO emissions_co2_2004 VALUES ('Solomon Islands', 175.98143999999999, 172);
INSERT INTO emissions_co2_2004 VALUES ('South Africa', 437031.57484000002, 173);
INSERT INTO emissions_co2_2004 VALUES ('Spain', 330496.81060000003, 174);
INSERT INTO emissions_co2_2004 VALUES ('Sri Lanka', 11534.11688, 175);
INSERT INTO emissions_co2_2004 VALUES ('Sudan', 10371.90612, 176);
INSERT INTO emissions_co2_2004 VALUES ('Suriname', 2284.0924399999999, 177);
INSERT INTO emissions_co2_2004 VALUES ('Swaziland', 956.89908000000003, 178);
INSERT INTO emissions_co2_2004 VALUES ('Sweden', 53032.7402, 179);
INSERT INTO emissions_co2_2004 VALUES ('Switzerland', 40457.399799999999, 180);
INSERT INTO emissions_co2_2004 VALUES ('Tajikistan', 5004.4722000000002, 182);
INSERT INTO emissions_co2_2004 VALUES ('Thailand', 268082.05988000002, 183);
INSERT INTO emissions_co2_2004 VALUES ('The former Yugoslav Republic of Macedonia', 10419.56776, 184);
INSERT INTO emissions_co2_2004 VALUES ('Timor-Leste', 175.98143999999999, 185);
INSERT INTO emissions_co2_2004 VALUES ('Togo', 2309.7564000000002, 186);
INSERT INTO emissions_co2_2004 VALUES ('Tonga', 117.32096, 187);
INSERT INTO emissions_co2_2004 VALUES ('Trinidad and Tobago', 32556.5664, 188);
INSERT INTO emissions_co2_2004 VALUES ('Tunisia', 22884.919760000001, 189);
INSERT INTO emissions_co2_2004 VALUES ('Turkey', 226125.15156, 190);
INSERT INTO emissions_co2_2004 VALUES ('Turkmenistan', 41725.932679999998, 191);
INSERT INTO emissions_co2_2004 VALUES ('Uganda', 1825.80744, 192);
INSERT INTO emissions_co2_2004 VALUES ('Ukraine', 330038.52559999999, 193);
INSERT INTO emissions_co2_2004 VALUES ('United Arab Emirates', 149188.26576000001, 194);
INSERT INTO emissions_co2_2004 VALUES ('United Kingdom', 587261.06412, 195);
INSERT INTO emissions_co2_2004 VALUES ('United Republic of Tanzania', 4351.8743599999998, 196);
INSERT INTO emissions_co2_2004 VALUES ('United States', 6049435.3256000001, 197);
INSERT INTO emissions_co2_2004 VALUES ('Uruguay', 5477.4223199999997, 198);
INSERT INTO emissions_co2_2004 VALUES ('Uzbekistan', 137907.12220000001, 199);
INSERT INTO emissions_co2_2004 VALUES ('Vanuatu', 87.990719999999996, 200);
INSERT INTO emissions_co2_2004 VALUES ('Venezuela', 172623.12752000001, 201);
INSERT INTO emissions_co2_2004 VALUES ('Western Sahara', 238.3082, 203);
INSERT INTO emissions_co2_2004 VALUES ('Yemen', 21114.106520000001, 204);
INSERT INTO emissions_co2_2004 VALUES ('Zambia', 2287.7587199999998, 205);
INSERT INTO emissions_co2_2004 VALUES ('Zimbabwe', 10558.886399999999, 206);
INSERT INTO emissions_co2_2004 VALUES ('Vietnam', 98663.261079999997, 202);
INSERT INTO emissions_co2_2004 VALUES ('Russia', 1524992.83228, 155);
INSERT INTO emissions_co2_2004 VALUES ('South Korea', 465643.22395999997, 103);
INSERT INTO emissions_co2_2004 VALUES ('North Korea', 79110.989839999995, 102);
INSERT INTO emissions_co2_2004 VALUES ('Myanmar (Burma)', 9759.6373600000006, 127);
INSERT INTO emissions_co2_2004 VALUES ('Iran', 433570.60651999997, 91);
INSERT INTO emissions_co2_2004 VALUES ('Libya', 59914.347759999997, 110);
INSERT INTO emissions_co2_2004 VALUES ('China', 5010169.5991200004, 39);
INSERT INTO emissions_co2_2004 VALUES ('Falkland Islands', 43.995359999999998, 65);
INSERT INTO emissions_co2_2004 VALUES ('Syria', 68420.117360000004, 181);


--
-- Name: emissions_co2_2004_pkey; Type: CONSTRAINT; Schema: public; Owner: nico; Tablespace: 
--

ALTER TABLE ONLY emissions_co2_2004
    ADD CONSTRAINT emissions_co2_2004_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

